/* 2026-01-21 11:53:16 [63 ms] */ 
CREATE TABLE user (
    userID int(8) ZEROFILL AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    userPassword VARCHAR(50) NOT NULL,
    role ENUM('Admin', 'SalesStaff', 'InventoryStaff') NOT NULL,
    contactInfo VARCHAR(50) NOT NULL
);
/* 2026-01-21 12:05:07 [43 ms] */ 
CREATE TABLE users (
    userID INT(8) ZEROFILL AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    userPassword VARCHAR(50) NOT NULL,
    role ENUM('Admin', 'SalesStaff', 'InventoryStaff') NOT NULL,
    contactInfo VARCHAR(50) NOT NULL
);
/* 2026-01-21 12:06:00 [32 ms] */ 
DROP TABLE user;
/* 2026-01-21 12:08:19 [28 ms] */ 
DROP TABLE users;
/* 2026-01-21 12:08:44 [35 ms] */ 
CREATE TABLE users (
    userID INT(8) AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    userPassword VARCHAR(50) NOT NULL,
    role ENUM('Admin', 'SalesStaff', 'InventoryStaff') NOT NULL,
    contactInfo VARCHAR(50) NOT NULL
);
/* 2026-01-21 12:08:45 [49 ms] */ 
CREATE TABLE backup (
    backupID INT(8) AUTO_INCREMENT PRIMARY KEY,
    userID INT(8),
    backupDate DATETIME NOT NULL,
    fileName VARCHAR(100) NOT NULL,
    backupType ENUM('Manual', 'Scheduled') NOT NULL,
    FOREIGN KEY (userID) REFERENCES users(userID)
);
/* 2026-01-21 12:20:07 [52 ms] */ 
DROP TABLE backup;
/* 2026-01-21 12:20:11 [53 ms] */ 
CREATE TABLE backup (
    backupID INT(8) AUTO_INCREMENT PRIMARY KEY,
    userID INT(8) NOT NULL,
    backupDate DATETIME NOT NULL,
    fileName VARCHAR(100) NOT NULL,
    backupType ENUM('Manual', 'Scheduled') NOT NULL,
    FOREIGN KEY (userID) REFERENCES users(userID)
);
/* 2026-01-21 12:20:18 [47 ms] */ 
CREATE TABLE sales_transaction (
    transactionID INT(8) AUTO_INCREMENT PRIMARY KEY,
    userID INT(8) NOT NULL,
    FOREIGN KEY (userID) REFERENCES users(userID),
    transDateTime DATETIME NOT NULL,
    totalAmount Decimal(10, 2) NOT NULL,
    paymentMethod VARCHAR(50) NOT NULL
);
/* 2026-01-21 12:30:34 [41 ms] */ 
CREATE TABLE supplier (
    supplierID INT(8) AUTO_INCREMENT PRIMARY KEY,
    supplierName VARCHAR(100) NOT NULL,
    contactNumber INT(25),
    email VARCHAR(50),
    address VARCHAR(250)
);
/* 2026-01-21 12:30:50 [48 ms] */ 
CREATE TABLE purchase_order (
    orderID INT(8) AUTO_INCREMENT PRIMARY KEY,
    userID INT(8) NOT NULL,
     FOREIGN KEY (userID) REFERENCES users(userID),
    supplierID INT(8) NOT NULL,
     FOREIGN KEY (supplierID) REFERENCES supplier(supplierID),
    orderDateTime DATETIME NOT NULL,
    status ENUM('Pending', 'Completed', 'Cancelled') NOT NULL
);
/* 2026-01-21 12:36:10 [59 ms] */ 
CREATE TABLE product (
    productID INT(8) AUTO_INCREMENT PRIMARY KEY,
    productName VARCHAR(250) NOT NULL,
    barcode VARCHAR(50) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL,
    stockQuantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    brand VARCHAR(50),
    productDescription VARCHAR(250)
);
/* 2026-01-22 17:43:03 [81 ms] */ 
CREATE TABLE report (
    reportID INT(8) AUTO_INCREMENT PRIMARY KEY,
    userID INT(8) NOT NULL,
        FOREIGN KEY (userID) REFERENCES users(userID),
    reportType ENUM('Sales Performance', 'User logs', 'Stock alerts') NOT NULL,
    generateDate DATETIME NOT NULL
);
/* 2026-01-22 17:48:34 [65 ms] */ 
CREATE TABLE sales_item (
    salesItemID INT(8) AUTO_INCREMENT PRIMARY KEY,
    transactionID INT(8) NOT NULL, 
        FOREIGN KEY (transactionID) REFERENCES sales_transaction(transactionID),
    productID INT(8) NOT NULL,
        FOREIGN KEY (productID) REFERENCES product(productID),
    quantity INT NOT NULL, 
    subtotal DECIMAL(10,2) NOT NULL
);
/* 2026-01-22 17:51:49 [66 ms] */ 
CREATE TABLE purchase_item (
    purchaseItemID INT(8) AUTO_INCREMENT PRIMARY KEY,
    orderID INT(8) NOT NULL,
        FOREIGN KEY (orderID) REFERENCES purchase_order(orderID),
    productID INT(8) NOT NULL,
        FOREIGN KEY (productID) REFERENCES product(productID),
    quantity INT NOT NULL,
    unitCost DECIMAL(10,2) NOT NULL
);
/* 2026-01-22 18:00:00 [76 ms] */ 
CREATE TABLE inventory_record (
    inventoryID INT(8) AUTO_INCREMENT PRIMARY KEY,
    userID INT(8) NOT NULL,
        FOREIGN KEY (userID) REFERENCES users(userID),
    productID INT(8) NOT NULL,
        FOREIGN KEY (productID) REFERENCES product(productID),
    actionType ENUM('Add', 'Edit', 'Archive') NOT NULL,
    quantityChange INT NOT NULL,
    inventoryDate DATETIME NOT NULL
);
